﻿$(document).ready(function () {
  
    function getOrdersByCustomer(fi, ff, inter) {
        var actiondata = "{'fi':'" + fi + "','ff':'" + ff + "'}";
        var uno;
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "Index.aspx/BuscarNumAleatorio",
            data: actiondata,
            dataType: "json",
            async: false,
            success: function (response) {
                var sep = response.d;
                grafica(sep);//Aqui mandamos a llamar la grafica
                
                
            },
            error: function (request, status, error) {
                alert(jQuery.parseJSON(request.responseText).Message);
            }
        });
    }

    $("#txtGrafica").click(function (e) {
        var fi = $(".txtfechainicio").val();
        var ff = $(".txtfechafin").val();
        if (fi != "" && ff != "" ) {
            getOrdersByCustomer(fi, ff);
            e.preventDefault();
        }
        else {
            alert("Complete los campos por favor.");
        }

    });
    function grafica(sep) {
        var arre = sep.replace("\"", "").split('-');
        Morris.Donut({
            element: 'graph',
            data: [
             { value: arre[0], label: 'Atendidas' },
             { value: arre[1], label: 'Perdias' },
             { value: arre[2], label: 'Total' },
             { value: arre[3], label: 'A really really long label' }
            ],
            formatter: function (x) { return x + "" }
        }).on('click', function (i, row) {
            console.log(i, row);
        });
    }
    /*Metodo para poner las clases de selección para la master page*/
    /*menu handler*/
    $('li').click(function () {

    });
});


